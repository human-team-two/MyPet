package com.example.team_pro_ex.Service.mypetboard.accommodation;

import com.example.team_pro_ex.Entity.mypetboard.accommodation.Accommodation;
import com.example.team_pro_ex.Entity.mypetboard.accommodation.AccommodationAnswer;

public interface AccommodationAnswerService {


    public void insertAnswer(Accommodation accommodation, String content) ;



}
