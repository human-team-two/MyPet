package com.example.team_pro_ex.persistence;

public class ss {
}
