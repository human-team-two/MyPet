package com.example.team_pro_ex.repository.mypetboard.foodCafe;

import com.example.team_pro_ex.Entity.mypetboard.foodandcafe.Menu;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuRepository extends JpaRepository<Menu, Long> {
}
