package com.example.team_pro_ex.repository.notice;

import com.example.team_pro_ex.Entity.notice.Reply;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReplyRepository extends JpaRepository<Reply,Long> {
}
