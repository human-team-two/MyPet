package com.example.team_pro_ex;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamProExApplicationTests {









}
